﻿using System;
using System.Runtime.Serialization;

namespace BlogService
{
  [DataContract]
  public class Post
  {
    [DataMember]
    public int Id { get; set; }

    [DataMember]
    public string Heading { get; set; }

    [DataMember]
    public string[] Tags { get; set; }

    [DataMember]
    public string PostedBy { get; set; }

    [DataMember]
    public string Content { get; set; }

    [DataMember]
    public DateTime PostedOn { get; set; }
  }
}
