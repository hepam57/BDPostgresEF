﻿
using System.ServiceModel;

namespace BlogService.Contracts
{
  [ServiceContract]
  public interface IBlogService
  {
    [OperationContract]
    Post GetPost(int postId);
    [OperationContract]
    int AddPost(Post post);
    [OperationContract]
    void EditPost(Post post);
    [OperationContract]
    void DeletePost(Post post);
  }   
}
