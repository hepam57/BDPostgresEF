﻿
using System;
namespace BlogService
{
  public interface ILogger
  {
    void Log(string info);
    void Log(Exception ex);
  }

  public class TextLogger : ILogger
  {
    public void Log(string info)
    {
    }

    public void Log(Exception ex)
    {
    }
  }
}
