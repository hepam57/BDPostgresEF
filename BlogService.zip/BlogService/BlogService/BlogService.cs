﻿using System;
using BlogService.Contracts;

namespace BlogService
{
  public class BlogService : IBlogService
  {
    private readonly ILogger _logger;
    private readonly IRepository _repository;

    public BlogService(ILogger logger, IRepository repository)
    {
      _logger = logger;
      _repository = repository;
    }

    public Post GetPost(int postId)
    {
      try
      {
        return _repository.GetPost(postId);
      }
      catch (Exception ex)
      {
        _logger.Log(ex);
        throw;
      }
    }

    public int AddPost(Post post)
    {
      try
      {
        return _repository.AddPost(post);
      }
      catch (Exception ex)
      {
        _logger.Log(ex);
        throw;
      }
    }

    public void EditPost(Post post)
    {
      try
      {
        _repository.EditPost(post);
      }
      catch (Exception ex)
      {
        _logger.Log(ex);
        throw;
      }
    }

    public void DeletePost(Post post)
    {
      try
      {
        _repository.DeletePost(post);
      }
      catch (Exception ex)
      {
        _logger.Log(ex);
        throw;
      }
    }
  }
}
