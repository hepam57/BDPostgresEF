﻿
using System;
namespace BlogService
{
  public interface IRepository
  {
    Post GetPost(int postId);
    int AddPost(Post post);
    void EditPost(Post post);
    void DeletePost(Post post);
  }

  public class Repository : IRepository
  {
    public Post GetPost(int postId)
    {
      return new Post
      {
        Id = 1,
        Heading = "Unit Testing WCF Services with Dependency Injection",
        Content = "In this article..",
        PostedBy = "Vijaya Anand",
        Tags = new[] { "dependency injection", "wcf" },
        PostedOn = DateTime.Now
      };
    }

    public int AddPost(Post post)
    {
      return 1;
    }

    public void EditPost(Post post)
    {
      
    }

    public void DeletePost(Post post)
    {
      
    }
  }
}
