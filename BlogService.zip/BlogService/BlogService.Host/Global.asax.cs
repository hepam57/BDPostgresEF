﻿using System;
using BlogService.Contracts;
using Castle.Facilities.WcfIntegration;
using Castle.MicroKernel.Registration;
using Castle.Windsor;

namespace BlogService.Host
{
  public class Global : System.Web.HttpApplication
  {
    IWindsorContainer _container;

    protected void Application_Start(object sender, EventArgs e)
    {
      _container = new WindsorContainer();

      _container.AddFacility<WcfFacility>()
        .Register
        (
          Component.For<ILogger>().ImplementedBy<TextLogger>(),
          Component.For<IRepository>().ImplementedBy<Repository>(),
          Component.For<IBlogService>()
                   .ImplementedBy<BlogService>()
                   .Named("BlogService")
        );
    }

    protected void Application_End(object sender, EventArgs e)
    {
      if (_container != null)
        _container.Dispose();
    }
  }
}