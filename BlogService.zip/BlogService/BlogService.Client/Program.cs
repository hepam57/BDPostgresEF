﻿using System.ServiceModel;
using BlogService.Contracts;
using Castle.Facilities.WcfIntegration;
using Castle.MicroKernel.Registration;
using Castle.Windsor;
using System;

namespace BlogService.Client
{
  class Program
  {
    static IWindsorContainer _container;

    static Program()
    {
      _container = new WindsorContainer();
      _container.AddFacility<WcfFacility>().Register
      (
        Component.For<IBlogService>()
        .AsWcfClient(new DefaultClientModel
        {
          Endpoint = WcfEndpoint.BoundTo(new BasicHttpBinding())
                                .At("http://localhost:58536/BlogService.svc")
        })
      );
    }

    static void Main(string[] args)
    {
      var client = _container.Resolve<IBlogService>();
      var post = client.GetPost(1);

      Console.WriteLine("Post details: \n************\nHeading: {0}\nPosted By: {1}\nPosted On: {2}", post.Heading, post.PostedBy, post.PostedOn);

      Console.ReadKey();

      if (_container != null)
        _container.Dispose();
    }
  }
}
