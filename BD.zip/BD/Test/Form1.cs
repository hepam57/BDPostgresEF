﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Test.Presentador;
using Business.Model;

namespace Test
{
    public partial class Form1 : Form ,IView
    {
        IClaseCampoPresenter ClaseCampoView;
        BD.Context context = new BD.Context();
        public Form1()
        {
            InitializeComponent();
            ClaseCampoView = new ClaseCampoPresenter(this, context);
        }

        public void PintarTodos(DataTable data)
        {
            dgvData.DataSource = data;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ClaseCampoView.SolicitarTodos();
        }
    }
}
