﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Business.DataAcces;
using Business.Model;
using Test.Commons;
using BD.Implementación;

namespace Test.Presentador
{
    public class ClaseCampoPresenter:IClaseCampoPresenter
    {
        private readonly IView view_;
        public IClaseCampoRepository claseCampoRepository { get; set; }
        public ClaseCampoPresenter(Form1 view , BD.Context context)
        {
            view_ = view;
            claseCampoRepository = new ClaseCampoRepository(context);
        }

        public List<ClaseCampo> GetAll()
        {
            return claseCampoRepository.GetAll();
        }

        public void SolicitarTodos()
        {
            List<ClaseCampo> claseCampos = claseCampoRepository.GetAll();
            view_.PintarTodos(Utils.ConvertToDataTable<ClaseCampo>(claseCampos));
        }
    }
}
