﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;
using BD.Entities;

namespace BD
{
    public class Context : DbContext
    {
        public Context(): base("name=SampleContext")
        {
        }

        public virtual DbSet<ClaseCampo> ClaseCampos { get; set; }

    }
}
