﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Business.DataAcces;
using Business.Model;

namespace BD.Implementación
{
    public class ClaseCampoRepository: IClaseCampoRepository
    {

        private readonly Context _Context;

        public ClaseCampoRepository(Context Context)
        {
            _Context = Context;
        }

        public List<ClaseCampo> GetAll()
        {
            return _Context.ClaseCampos
                                 .ToList().Select(e => Mappings.Mapper.Map<Business.Model.ClaseCampo>(e))
                                 .OrderBy(c => c.IdClaseCampo).ToList();
        }
    }
}
