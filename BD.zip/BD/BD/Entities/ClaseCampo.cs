﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity.Spatial;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BD.Entities
{
    [Table("davivienda_cd.clasecampo")]
    public partial class ClaseCampo
    {

        public Guid IdClaseCampo { get; set; }

        //[DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        //public int Number { get; set; }

        [Required]
        [StringLength(100)]
        public string NombreClaseCampo { get; set; }

        [Required]
        [StringLength(4)]
        public string CodigoClaseCampo { get; set; }

        [Required]
        public DateTime Fecha { get; set; }

        [Required]
        public bool Habilitado { get; set; }

    }
}
