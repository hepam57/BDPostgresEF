﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business.Model
{
    public class ClaseCampo
    {
        public Guid IdClaseCampo { get; set; }
        public string NombreClaseCampo { get; set; }
        public string CodigoClaseCampo { get; set; }
        public DateTime Fecha { get; set; }
        public bool Habilitado { get; set; }
    }
}
